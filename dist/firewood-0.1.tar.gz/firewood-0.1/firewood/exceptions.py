# coding:utf-8


class NoSessionKey():
    pass
