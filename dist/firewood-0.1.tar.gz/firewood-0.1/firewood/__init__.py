# coing:utf-8

from .firewood import Firewood

fw = Firewood()
